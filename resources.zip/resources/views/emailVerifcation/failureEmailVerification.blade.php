<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification Failed</title>
</head>
<body style="font-family: 'Arial', sans-serif;">

    <div style="text-align: center; padding: 20px;">
        <h2>Email Verification Failed</h2>
        <p>Sorry, your email verification has failed. Please check the link and try again.</p>
    </div>

    <div style="text-align: center; padding: 20px;">
        <p>If you continue to experience issues, please contact our support team.</p>
    </div>

</body>
</html>